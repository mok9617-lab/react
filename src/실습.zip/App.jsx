import "./App.css";
import mok from "./assets/mok.png";

function App() {
  const user = {
    name: "하경목",
    job: "리액트 개발자",
    age: 28,
    skills: ["React", "JavaScript", "CSS"],
  };

  return (
    <div className="profile-card">
      <img src={mok} alt="" className="img" />
      <h1 style={{ fontWeight: "bold", color: "blue", textAlign: "center" }}>
        {user.name}
      </h1>

      <p style={{ textAlign: "center" }}>
        {user.job} | {user.age}살
      </p>
      <div>
        <h3>보유 스킬:</h3>
        <p>{user.skills.join(", ")}</p>
      </div>
    </div>
  );
}

export default App;
